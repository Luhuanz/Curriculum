from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.common.by import By
# from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from chaojiying import Chaojiying_Client
import csv
import base64
import json
import cv2
from openpyxl import Workbook
import requests
from PIL import Image
from time import sleep
import  re
import random
driver = webdriver.Chrome()
driver.get('http://eia-data.com/pm_day_history-html/')
# 使用XPath找到输入框并输入数据
driver.implicitly_wait(10)
station_number = driver.find_element_by_xpath('/html/body/div[1]/div/div[2]/main/div/div[1]/div/input[1]')
station_number.clear()
station_number.send_keys('1205A')
driver.implicitly_wait(2)
starting_time = driver.find_element_by_xpath('/html/body/div[1]/div/div[2]/main/div/div[1]/div/input[2]')
starting_time.clear()
driver.implicitly_wait(3)
starting_time.send_keys('2023-01-01')
end_time = driver.find_element_by_xpath('/html/body/div[1]/div/div[2]/main/div/div[1]/div/input[3]')
end_time.clear()
driver.implicitly_wait(3)
end_time.send_keys('2023-12-31')
element = WebDriverWait(driver, 6).until(
    EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div[2]/main/div/div[1]/div/button'))
) #等待元素加载为了让ajaxs能够加载完
element.click()
sleep(4)
# 解决验证码 1. 打码平台（money） 2.使用opengl计算图片距离
# 定位ifframe的位置 其实是一个新的网页
# 切换到 iframe
driver.switch_to.frame("tcaptcha_iframe_dy")
# 等待滑块验证图片加载后，再做后面的操作
WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, 'slideBg')))
# 获取滑块验证图片下载路径，并下载到本地
bigImage = driver.find_element(By.ID, "slideBg")
bigImage.screenshot('smallImage.png')
s = bigImage.get_attribute("style")  # 获取图片的style属性
# 设置能匹配出图片路径的正则表达式
p = 'background-image: url\(\"(.*?)\"\);'
# 进行正则表达式匹配，找出匹配的字符串并截取出来
bigImageSrc = re.findall(p, s, re.S)[0]  # re.S表示点号匹配任意字符，包括换行符
response = requests.get(bigImageSrc)
with open('bigImage.png', 'wb') as file:
    file.write(response.content)
# #分析缺口位置
chaojiying = Chaojiying_Client('sourant', 'mathssuifeng6', '956905')  # 用户中心>>软件ID 生成一个替换 96001
im1 = open('smallImage.png', 'rb').read()
zuobiao=chaojiying.PostPic(im1, 9104)
print(zuobiao)  # 1902 验证码类型  官方网站>>价格体系 3.4+版 print 后要加()

# 平台2
# api_post_url = "http://www.bingtop.com/ocr/upload/"
# with open('smallImage.png','rb') as pic_file:
#     img64=base64.b64encode(pic_file.read())
# api_username="luke"
# api_password="PtgScjL5kQfiq2a"
# params = {
#     "username": "%s" % api_username,
#     "password": "%s" % api_password,
#     "captchaData": img64,
#     "captchaType": 1326
# }
# response = requests.post(api_post_url, data=params)
# dictdata=json.loads(response.text)
# print(dictdata)

# im2 = open('smallImage.png', 'rb').read()  # 本地图片文件路径 来替换 a.jpg 有时WIN系统须要//
# print(chaojiying.PostPic(im2, 9103))  # 1902 验证码类型  官方网站>>价格体系 3.4+版 print 后要加()
sleep(5)
# 从zuobiao字典中获取坐标字符串
pic_str = zuobiao['pic_str']
# 分解坐标字符串并转换为整数
x1, y1 = map(int, pic_str.split('|')[0].split(','))  # 第一个滑块的坐标
x2, y2 = map(int, pic_str.split('|')[1].split(','))  # 第二个滑块的坐标
# 获取小滑块元素，并移动它到上面的位置
smallhuadong = driver.find_element(By.XPATH, '//*[@id="tcOperation"]/div[6]')

newDis = abs(x2 - x1)
driver.implicitly_wait(5)  # 使用浏览器隐式等待5秒
# 按下小滑块按钮不动
ActionChains(driver).click_and_hold(smallhuadong).perform()
# 移动小滑块，模拟人的操作，一次次移动一点点
i = 0
moved = 0
# 随机延时函数
def random_sleep(min_seconds, max_seconds):
    sleep(random.uniform(min_seconds, max_seconds))
while moved < newDis:
    x = random.randint(1, 10)  # 每次移动3到10像素
    moved += x
    ActionChains(driver).move_by_offset(xoffset=x, yoffset=0).perform()
    print("第{}次移动后，位置为{}".format(i, smallhuadong.location['x']))
    i += 1
    random_sleep(0.05,0.1)
# 移动完之后，松开鼠标
ActionChains(driver).release().perform()
# 整体等待5秒看结果
sleep(5)
# 跳出 iframe 到默认上下文
driver.switch_to.default_content()
rows = driver.find_elements_by_xpath('/html/body/div[1]/div/div[2]/main/div/div[2]/div/table/tbody/tr')
# 创建一个新的 Excel 文件
workbook = Workbook()
# 遍历每一行并将数据写入 Excel
for row_index, row in enumerate(rows, start=1):
    # 找到该行下的所有单元格元素
    cells = row.find_elements_by_tag_name('td')

    # 遍历每个单元格并将数据写入 Excel
    for cell_index, cell in enumerate(cells, start=1):
        # 获取单元格文本
        cell_text = cell.text

        # 将数据写入 Excel 表格中，这里假设行和列的索引从 1 开始
        sheet.cell(row=row_index, column=cell_index, value=cell_text)

# 保存 Excel 文件
workbook.save('output.xlsx')