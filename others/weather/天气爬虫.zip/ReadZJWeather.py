
import requests
from requests.compat import urljoin
from bs4 import BeautifulSoup
import re
import time
import urllib.request
from lxml import etree
import  random
import csv
csv_file_path = 'zhenjiang.csv'
base_url = 'http://www.tianqihoubao.com/lishi/zhenjiang/month/'
Year = 2023

# 生成月份从01到12的URL数组
url_list = [f'{base_url}{Year}{month:02d}.html' for month in range(1, 13)]
print(url_list)
uapools = [
             'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36',
             "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393",
             "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.22 Safari/537.36 SE 2.X MetaSr 1.0",
             "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Maxthon 2.0)",
             "Mozilla/5.0 (compatible; ABrowse 0.4; Syllable)",
         ]

def get_randomheaders():
    thisua = random.choice(uapools)  # 随机选择一个请求头
    headers = ("User-Agent", thisua)  # 构建请求头
    opener = urllib.request.build_opener()  # 添加opener
    opener.addheaders = [headers]
    # 安装为全局
    urllib.request.install_opener(opener)  # 这边headers输出的是元组
    header = {}
    headers_list = list(headers)
    header[headers_list[0]] = headers_list[1]
    # header['Cookie'] = cookie.encode("utf-8").decode("latin1")
    # print(header)
    return header
def get_url_html(url, headers):
     try:
         response = requests.get(url=url, headers=headers)
         return  response.text
     except Exception as e:
         print(e)
         return  None


if __name__ == '__main__':
    # 爬取镇江天气数据
    for i in range(6,len(url_list)):
        print("第{}月".format(i+1))
        head = get_randomheaders()
        response = get_url_html(url_list[i], head)
        soup = BeautifulSoup(response, 'html.parser')
        # 找到表格
        table = soup.find('table')
        if table is not None:
            rows = table.find_all('tr')
        else:
            rows = soup.find_all('tr')
        # print(table)
        # 获取表格中的所有行

        # print(rows)
        # print(type(rows))
        # print(len(rows))
        # exit()
        # exit()
        # 遍历表格行
        all_rows_data=[]
        for row in rows:
            #初始化一个列表
            row_data=[]
            # 找到当前行中的所有单元格
            cells = row.find_all(['td', 'th'])
            # 遍历每个单元格
            for cell in cells:
                # 获取单元格文本，并去除首尾空格
                cell_text = cell.get_text(strip=True).replace('\r', '').replace('\n', '').replace(' ', '')
                # 将单元格文本添加到当前行的数据列表中
                row_data.append(cell_text)
                # print(row_data)
                # exit()
            # 将当前行的数据列表添加到所有行数据列表中
            all_rows_data.append(row_data)
        with open(csv_file_path, 'a', newline='', encoding='utf-8') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerows(all_rows_data)

    print('---------------------end----------------')