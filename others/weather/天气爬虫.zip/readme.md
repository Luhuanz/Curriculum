-  air_zhenjiang_2023.py  你的

###  爬tiaoqihoubao

http://www.tianqihoubao.com/lishi/zhenjiang/month/202301.html

 

**ReadZJWeather.py**

 **output: zhenjiang.csv**

任务1

###  爬天气质量

- 视频.mp4
- smallimage.png
- chaojiying.py打码平台
- output.xslx （不过我ip被封了，测试不了，应该没啥问题）
- 入口tianqi_2023.py 



两个随便选一个 建议第一个