document.querySelector(".search button").addEventListener("click", function() {
    fetchWeatherDataAndDisplay(formatInputDate(document.querySelector(".search-bar").value));
});

document.querySelector(".search-bar").addEventListener("keyup", function(event) {
    if (event.key == "Enter") {
        fetchWeatherDataAndDisplay(formatInputDate(event.target.value));
    }
});

document.querySelector(".search-bar").addEventListener('input', function(e) {
    var input = e.target.value;

    // 移除所有非数字字符
    var numericInput = input.replace(/[^\d]/g, '');

    // 切割数字为年月日
    var year = numericInput.substr(0, 4);
    var month = numericInput.substr(4, 2);
    var day = numericInput.substr(6, 2);

    // 构建新的格式化字符串
    var formattedInput = year;
    if (month) formattedInput += "年" + month;
    if (day) formattedInput += "月" + day + "日";

    // 防止无限循环
    if (input !== formattedInput) {
        e.target.value = formattedInput;
    }
});

function formatInputDate(date) {
    // 将输入格式化为 YYYY年MM月DD日
    var matches = date.match(/(\d{4})年?(\d{2})月?(\d{2})日?/);
    if (matches) {
        return `${matches[1]}年${matches[2]}月${matches[3]}日`;
    } else {
        return date;
    }
}
//数据展示
function fetchWeatherDataAndDisplay(date) {
    fetch('data.json') // 确保这里的路径导入json
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            const cleanDate = date.replace(/\s+/g, ''); //处理收到的数据
            const weatherForDate = data.find(entry => entry["日期"].replace(/\s+/g, '') === cleanDate);//对比数据差别
            if (weatherForDate) {
                displayWeather(weatherForDate);
            } else {
                alert("No weather data found for this date.");
            }
        })
        .catch(error => {
            console.error("Error fetching the weather data: ", error);
            alert("Error fetching the weather data: " + error.message);
        });
}

function displayWeather(data) {
    // 加图标
    // 根据"天气状况" 把所有可能加入iconMap中
    const iconMap = {
        "Clear": "01d", // 示例：晴天
        "多云/多云": "02d", // 示例：多云
        "Rain": "09d", // 示例：雨
        "Thunderstorm": "11d", // 示例：雷暴
        // ""
        // // 添加其他天气状况到图标的映射
    };

    const iconCode = iconMap[data["天气状况"]] || "01d"; // 如果没有匹配项，默认为晴天图标
    const iconUrl = `https://openweathermap.org/img/wn/${iconCode}.png`;
    document.querySelector(".time").innerText = "Weather on " + data["日期"];
    document.querySelector(".icon").src = iconUrl; // 更新图标
    document.querySelector(".description").innerText = data["天气状况"];
    document.querySelector(".temp").innerText = data["最低气温/最高气温"];
    document.querySelector(".wind").innerText = data["风力风向(夜间/白天)"];
}
